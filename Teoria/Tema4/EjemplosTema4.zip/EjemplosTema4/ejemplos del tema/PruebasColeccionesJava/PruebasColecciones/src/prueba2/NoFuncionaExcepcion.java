/*
 * Del libro "Java 6. Los fundamentos del lenguaje Java". Ed. Eni
 * ¡Lo tenéis en la biblioteca!
 * 
 * Excepciones
 */

package prueba2;

public class NoFuncionaExcepcion extends Exception{

        public NoFuncionaExcepcion()
        {
            super();
        }
        public NoFuncionaExcepcion(String mensaje)
        {
            super(mensaje);
        }
        public NoFuncionaExcepcion(String mensaje, Throwable causa)
        {
            super(mensaje,causa);
        }
        public NoFuncionaExcepcion(Throwable causa){
            super(causa);
        }
}
