package prueba2;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Main {

    public static void main(String[] args) {
        
//        // EJEMPLO 1: ¿Por qué da error el siguiente trozo de código? ¿cómo lo arreglarías?
//        ArrayList saco = new ArrayList();
//        saco.add(1234);

        // EJEMPLO 2: Ejecuta el siguiente trozo de código y comprueba cuál es el resultado
//        HashSet conjunto = new HashSet() {};
//        conjunto.add("Esto");
//        conjunto.add("es");
//        conjunto.add("una");
//        conjunto.add("prueba");
//        conjunto.add("con");
//        conjunto.add("una");
//        conjunto.add("colección");
//        
//        Iterator it = conjunto.iterator();
//        while(it.hasNext()){
//            System.out.println(it.next());
//        }

        // EJEMPLO 3: Ahora ejecuta este otro... ¿cuál es la diferencia?
//        ArrayList conjunto2 = new ArrayList();
//        conjunto2.add("Esto");
//        conjunto2.add("es");
//        conjunto2.add("una");
//        conjunto2.add("prueba");
//        conjunto2.add("con");
//        conjunto2.add("una");
//        conjunto2.add("colección");
//        
//        Iterator it2 = conjunto2.iterator();
//        while(it2.hasNext()){
//            System.out.println(it2.next());
//        }
        
        // EJEMPLO 4: Ejecuta el método main en ArrayListTester.java con el depurador,
        // ¿qué ocurre en cada paso?
        
        // EJEMPLO 5: Ejecuta LinkedList.java y responde a las preguntas que allí se proponen
        
        // EJEMPLO 6: Comprueba el funcionamiento de las tablas hash ejecutando MapTest.java, responde a las preguntas que se proponen
        
        // EJEMPLO 7: Comprueba el uso de los métodos de ordenación de Collections ejecutando ShuffleTest.java
        
        // EJEMPLO 8: Comprueba el uso de los comparadores ejecutando TreeSetTest.java
        
    }
    
}
