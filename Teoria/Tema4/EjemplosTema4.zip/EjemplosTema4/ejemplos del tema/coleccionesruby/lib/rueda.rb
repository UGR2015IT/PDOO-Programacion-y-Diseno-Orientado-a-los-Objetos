# To change this template, choose Tools | Templates
# and open the template in the editor.


class Rueda
  include Comparable

  attr_accessor :diametro,:grosor   
  
  def initialize (unDiametro, unGrosor)
    #Atributos de ámbito de instancia:
    @diametro=unDiametro
    @grosor=unGrosor
  end   

  #Métodos:
  def to_s
     "Diametro: #{diametro}  y Grosor: #{grosor}"
  end
   # EJERCICICO: Redefine el método == para que la comparación de objetos sea por estado y no por identidad.

  def  <=>(rueda)
    resultado=0
    if @diametro > rueda.diametro
      resultado=-1
    else 
      if @diametro == rueda.diametro
        if @grosor > rueda.grosor
          resultado=-1
        else
          if @grosor == rueda.grosor
             resultado=0
          else
             resultado=1
          end
        end
      else
        resultado=1
      end
    end
    return resultado
  end

end