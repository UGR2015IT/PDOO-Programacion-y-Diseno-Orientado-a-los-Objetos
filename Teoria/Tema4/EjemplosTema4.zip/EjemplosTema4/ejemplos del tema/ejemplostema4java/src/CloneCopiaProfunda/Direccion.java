/*
 *  * Clase Dirección con método clone para copiar en profundidad
 */
package CloneCopiaProfunda;

/**
 *
 * @author ana
 */
class Direccion {
     String calle;
      int numero;
      String codigoPostal;
      String ciudad;

    Direccion(String calle, int num, String cp, String ciudad) {
        this.calle = calle;
        this.numero = num;
        this.codigoPostal = cp;
        this.ciudad = ciudad;    
    } 
    public Direccion(Direccion dc) {
        this.calle = dc.calle;
        this.numero =dc.numero;
        this.codigoPostal = dc.codigoPostal;
        this.ciudad = dc.ciudad;    
    } 
    // Uso de constructor de copia en profundidad  
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return new Direccion (calle,numero,codigoPostal,ciudad);
    }    
}
