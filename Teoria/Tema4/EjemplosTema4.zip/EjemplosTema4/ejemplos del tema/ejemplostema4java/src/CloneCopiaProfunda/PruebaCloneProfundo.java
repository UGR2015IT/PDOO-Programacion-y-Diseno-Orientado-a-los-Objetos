/*
 * Ejemplo para comparar con la copia superficial de clone.
 */
package CloneCopiaProfunda;
 

/**
 *
 * @author ana
 */
public class PruebaCloneProfundo {
    public static void main(String argsString[]) throws CloneNotSupportedException {

    Direccion d1= new Direccion("Calle del Agua", 58, "18888", "Murcia");

    Persona p1 = new Persona("Juan", 30, d1); 
    Persona p2 = (Persona) p1.clone();
    System.out.println("Nombre del objeto p1 "+p1.nombre);
    p2.nombre = "Luis";     
    System.out.println("Nombre del objeto p1 "+ p1.nombre); 

    System.out.println("La ciudad de p2, " + p2.nombre + ", es " + p2.dir.ciudad);
    p2.dir.ciudad = "Huelva";
    System.out.println("La ciudad de p1, " + p1.nombre + ", es " + p1.dir.ciudad);
    System.out.println("La ciudad de p2, " + p2.nombre + ", es " + p2.dir.ciudad);
    
    }  
}
