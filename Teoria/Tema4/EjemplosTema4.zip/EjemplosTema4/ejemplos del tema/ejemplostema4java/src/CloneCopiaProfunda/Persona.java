/*
 *  * Clase Persona con método clone para copiar en profundidad
 */
package CloneCopiaProfunda; 
/**
 *
 * @author ana
 */
class Persona {
        String nombre;
        int edad;
        Direccion dir;
    
    Persona(String n, int e, Direccion d) {
        this.nombre=n;
        this.edad=e;
        this.dir= new Direccion(d);
    }
    // uso del constructor de copia en profundidad
    @Override
    protected Object clone() throws CloneNotSupportedException {
       return  new Persona(nombre,edad,dir);
        
    }
}
