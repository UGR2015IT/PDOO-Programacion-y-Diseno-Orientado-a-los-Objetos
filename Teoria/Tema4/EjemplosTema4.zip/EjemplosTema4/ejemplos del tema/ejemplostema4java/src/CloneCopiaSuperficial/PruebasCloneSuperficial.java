/*
 * Ejemplo de uso de asignación y clone por defecto para copiar objetos
 */
package CloneCopiaSuperficial; 
/**
 *
 * @author ana
 */

// prueba de la copia superficial de objetos usando clone()
public class PruebasCloneSuperficial {
    
   public static void main(String argsString[]) throws CloneNotSupportedException {
    System.out.println("Prueba de clonación de objetos");
    
    Direccion d1= new Direccion("Calle del Agua", 58, "18888", "Murcia");

    Persona p1 = new Persona("Juan", 30, d1); 
    
    Persona p3=p1;  //prueba de asignación
    p1.nombre="Alfonso";
    System.out.println(p3.nombre);
    
    Persona p2 = (Persona) p1.clone();//clonación superficial
    System.out.println("Nombre del objeto p1 "+ p1.nombre);
    p2.nombre = "Luis";     
    System.out.println("Nombre del objeto p1 "+p1.nombre); 
    
        

    System.out.println("La ciudad de p2, " + p2.nombre + ", es " + p2.dir.ciudad);
    p2.dir.ciudad = "Huelva";
    System.out.println("La ciudad de p1, " + p1.nombre + ", es " + p1.dir.ciudad);
    System.out.println("La ciudad de p2, " + p2.nombre + ", es " + p2.dir.ciudad);
    
    }  
} 
    

