/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Excepciones;

/**
 *
 * @author ana
 */
public class DireccionException extends Exception{
    public DireccionException(String error){
        super(error);
    }    
}
