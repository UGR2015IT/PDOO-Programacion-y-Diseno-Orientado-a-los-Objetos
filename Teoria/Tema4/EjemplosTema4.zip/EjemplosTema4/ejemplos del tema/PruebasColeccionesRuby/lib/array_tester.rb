accounts = Array.new
accounts.push(BankAccount.new(1001))      #añadir un elemento al final del array
accounts.push(BankAccount.new(1015))
accounts.push(BankAccount.new(1729))
accounts.insert(1, BankAccount.new(1008)) #insertar un elemento en una cierta posición
accounts.delete_at(0)   #eliminar un elemento de uan cierta posición

puts "size="+accounts.size.to_s
first = accounts.at(0)
puts "first account number="+first.account_number.to_s
last = accounts.at(accounts.size-1)
puts "last account number="+last.account_number.to_s
