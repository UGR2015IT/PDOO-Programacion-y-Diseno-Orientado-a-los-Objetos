
class BankAccount
  attr_accessor :account_number, :balance
  
  def initialize(*args)
    case args.size
			when 1
        @account_number = args
      when 2
        @account_number, @balance = args
    end
  end
  
  def deposit(amount)
    @balance += amount
  end
  
  def withdraw(amount)
    @balance -= amount
  end
end
