require 'set'
require_relative 'bank_account'
require_relative 'employee'

#EJEMPLO 1: ¿Por qué en Ruby este trozo de código no da error?
=begin
saco = Array.new
saco.push(1234)
=end

#EJEMPLO 2: Ejecuta este trozo de código y comprueba qué pasa
=begin
conjunto = Set.new
conjunto.add("Esto")
conjunto.add("es")
conjunto.add("una")
conjunto.add("prueba")
conjunto.add("con")
conjunto.add("una")
conjunto.add("coleccion")

conjunto.each do |elemento|
  print elemento+"\n"
end
=end

#EJEMPLO 3: Ejecuta este otro y compáralo con el anterior
=begin
lista = Array.new
lista.push("Esto")
lista.push("es")
lista.push("una")
lista.push("prueba")
lista.push("con")
lista.push("una")
lista.push("coleccion")

lista.each do |elemento|
  print elemento+"\n"
end
=end

#EJEMPLO 4: Ejecuta array_tester y comprueba qué pasa

#EJEMPLO 5: Comprueba cómo se trabaja con listas descomentando cada put por separado
#Más ejemplos en http://ruby-doc.org/core-2.0.0/Array.html
=begin
a = ["Amy", "Carl", "Erica"]
b = ["Bob", "Doug", "Frances", "Gloria"]
a.push(b)
#puts a
#puts a.take(2)
#puts a.drop(1)
#puts a.drop(a.size-1)
#puts a.clear
=end

#EJEMPLO 6: Comprueba cómo se trabaja con tablas Hash descomentado cada puts por separado
#Más en http://ruby-doc.org/core-2.0.0/Hash.html
=begin
staff = Hash.new
staff["144-25-5464"] = Employee.new("Amy Lee")
staff["567-24-2546"] = Employee.new("Harry Hacker")
staff["157-62-7935"] = Employee.new("Gary Cooper")
staff["456-62-5527"] = Employee.new("Francesca Cruz")

#puts "The size of the hash is #{staff.size}"
#puts staff.keys.inspect
#puts staff.values.inspect
#puts staff.to_s
#puts staff.has_key?"144-25-5464"
#Ejecuta los trozos de código que aparecen en http://zetcode.com/lang/rubytutorial/hashes
=end

#EJEMPLO 7: Comprueba cómo se ordenan colecciones 
#a = [89, 9, 23, 5, 234, 1, 25]
#puts a.sort

#EJEMPLO 8: Aprende a usar comparadores personalizados en el fichero comparador.rb








