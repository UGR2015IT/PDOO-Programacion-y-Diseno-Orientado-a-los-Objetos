
class Employee
  attr_reader :name,:salary
  
  def initialize n
    @name = n
    @salary = 0
  end
  
  def to_s
    return "[name="+@name.to_s+", salary="+@salary.to_s+"]";
  end
end
