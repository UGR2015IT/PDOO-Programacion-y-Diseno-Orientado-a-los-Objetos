#custom comparator de: http://stackoverflow.com/questions/4622206/ruby-how-to-pass-a-custom-comparator-to-sort
#descomenta los puts uno a uno y comprueba qué ocurre

class SizeMatters
  include Comparable
  attr :str
  def <=>(anOther)
    str.size <=> anOther.str.size
  end
  def initialize(str)
    @str = str
  end
  def inspect
    @str
  end
end

s1 = SizeMatters.new("Z")
s2 = SizeMatters.new("YY")
s3 = SizeMatters.new("XXX")
s4 = SizeMatters.new("WWWW")
s5 = SizeMatters.new("VVVVV")

#puts s1 < s2                       
#puts s4.between?(s1, s3)           
#puts s4.between?(s3, s5)           
#puts [ s3, s2, s5, s4, s1 ].sort   