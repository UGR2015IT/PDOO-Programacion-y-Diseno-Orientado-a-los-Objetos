#encoding: UTF-8
# 
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'bicicleta.rb'
require_relative 'ciclista.rb'
require_relative 'club.rb'  # para poder acceder a todo lo definido en estos archivos


module El_Ciclista 
     

   miBici = Bicicleta.new;
   miClub = Club.new("los intrépidos", "trevenque 2, bajo B")
   ciclista = Ciclista.new("Pepe",30,miBici,miClub)
   puts ciclista.to_s
   
   # Continúa haciendo pruebas de todo el código
end
