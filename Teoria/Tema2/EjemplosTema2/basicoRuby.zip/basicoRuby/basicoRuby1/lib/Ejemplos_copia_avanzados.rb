##  Proceder como se ha indicado main.rb
#
##-------------------------------------------------------------------------
##-------------- Ejemplos avanzados en Ruby
##-------------------------------------------------------------------------
#
##-------------------1. Uso de clone-------------------
#
## clone hace una copia superficial(shallow copy) del objeto 
#
#class Coche
#  attr_accessor :ruedas    
#  def initialize (r)
#     @ruedas = r
#  end
#  def mod_rue(v) # lo pongo para ver que con clone se comparte las modificaciones a un segundo nivel    ruedas[1]= v
#  end
#end

#a=Coche.new('60')
#b=a.clone

#puts a.inspect
#puts b.inspect
#
#b.mod_rue('7') # Esta modificación se ve desde las dos referencias.
#puts a.inspect
#puts b.inspect

##---------------2. Probando clone y freeze--------------------------------------
#
## Ve poniendo y quitando # en la 2º, 3ª,6ª y 9ª línea hasta llegar a la conclusión de que tanto
## freeze como clone hace inmutable y copia objeto, respectivamente, de forma superfical
## es decir, a un primer nivel
#
#var1=['abc','def']
#var1.freeze
#var2=var1.clone 
#puts var1.inspect
#puts var2.inspect
#var2[0]='x'      # modificación del primer nivel
#puts var1.inspect
#puts var2.inspect
#var2[0][0]='x' # modificación a un segundo nivel
#puts var1.inspect
#puts var2.inspect

##-------------------3. Uso de dup-----------------------------------------------
## el dup hace una copia profunda (deep copy) del objeto
#  
#var1=['abc','def']
#var2=var1.dup # crea otra variable y otro objeto copia del objeto al que apunta var2
#puts var1.inspect
#puts var2.inspect
#var2[0]='xyz' 
#puts var1.inspect
#puts var2.inspect
#var2[0][0]='m' 
#puts var1.inspect
#puts var2.inspect

## === Probar esto último con la clase coche definida anteriormente ===
 

  