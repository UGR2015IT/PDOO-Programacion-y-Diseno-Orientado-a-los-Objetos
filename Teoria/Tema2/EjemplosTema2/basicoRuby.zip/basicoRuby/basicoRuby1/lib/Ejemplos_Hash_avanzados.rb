##  Proceder como se ha indicado main.rb
#
##-------------------------------------------------------------------------
##-------------- Ejemplos de uso de Hash en Ruby
##-------------------------------------------------------------------------
#

##-------------------1. Creando y recorriendo un hash -------------------------
#
#edificio ={"uno"=> "primero", "dos"=>"segundo", "tres"=>"tercero"}
#puts edificio
#piso=""
#edificio.each {|k, v| piso << "#{k} es el #{v} \n"}
#puts piso

##------------------2. Accediendo a elementos del hash ------------------------
#
#numeros={'uno'=>1, 'dos'=>2, 'tres'=>3}
#puts numeros.inspect
#numerosx=Hash['uno', 1, 'dos', 2, 'tres',3]
#puts numerosx.inspect
#
#puts numeros['uno']
#numeros['veinte']=20
#numeros['tres']=33
#numeros['cuatro'] = 4
#puts numeros.inspect
#
#puts numeros.keys
#puts numeros.values
#
#puts numeros.to_a.inspect
#
#puts numeros['nada']
#puts numeros.keys.grep /o/  # muestra los que contengan la letra 'o' en key

##----------------3. Mezclando hash ---------------------------------------------
#
#letras={'vocal1'=>'a', 'vocal2'=>'e','vocal3'=>'i','vocal4'=>'o','vocal5'=>'u'}
#
#numeros={'uno'=>1, 'dos'=>2, 'tres'=>3}
#
#numeros.merge!(letras)
#puts numeros.inspect
#
#numeros2={'uno'=>11, 'dos'=>22, 'cinco'=>55}
#numeros.replace(numeros2)
#puts numeros.inspect
#
#numeros.each do |x| puts x.inspect 
#end

##---------------4. Borrando elementos del hash --------------------------------
#
#letras={'vocal1'=>'a', 'vocal2'=>'e','vocal3'=>'i','vocal4'=>'o','vocal5'=>'u'}
#letras.delete('vocal2')
#puts letras.inspect
#

##---------------5. Borrando elementos si se da una condición -------------------
#
#numeros2={'uno'=>11, 'dos'=>22, 'cinco'=>55}
#numeros2.delete_if {|k,v| v>30}
#puts numeros2.inspect

##--------------6. Diferencia de métodos reverse e invert 
#
#palabra="unacosa"
#numeros={'uno'=>1, 'dos'=>2, 'tres'=>3}
#numeros[:palabra]='otracosa'
#numeros[palabra]='mascosas'
#puts numeros.inspect

#puts palabra.reverse!
#puts numeros.inspect
#puts numeros.invert.inspect

##-------------7. Arrays de asociaciones: each_pair, each_key, each_value ------
#
#grupos ={1=>['a','b'], 2=>['c','d']}
#puts grupos[2].inspect
#grupos[2]<<'e'
#puts grupos[2].inspect
#grupos.each_pair {|k,v| puts "#{k.inspect} es #{v.inspect}"}
#grupos.each_key { |k| puts k*3}

## pensad detenidamente qué ocurre cuando se ejecuta el siguiente código
#
#personas={'Luis'=>'Granada', 'Ana'=>'Sevilla', 'Pepe'=>"Granada"}
#cuenta=Hash.new 0 
#personas.each_value { |x| cuenta[x]+=1 }
#puts cuenta.inspect

 