#encoding: utf-8 

##----------1.Clase: Constructores, sobreescritura y sobrecarga de métodos -----
##
#
#class Alumno
#  attr_reader :nombre,:carrera,:beca
#	def initialize(*args)
#		case args.size
#			when 2
#				@nombre, @carrera=args
#			when 3
#				@nombre, @carrera, @beca=args
#			else
#				raise ArgumentError, "faltan o sobran argumentos"    # Se lanza una excepción
#			end
#	end
#  def to_s   # Redefinción o sobrescritura  de to_s
#    return  "nombre = #{nombre}", "Estudia = #{carrera}", "Con beca = #{beca}"
#  end
#end
#
## ------ 1.1 Distintas formas de construir un objeto --------------------------
## Elimina el error (quitando la sentencias que correspondan) y vuelve a probar
#
#begin
#      alu0 = Alumno.new      
#      rescue Exception => e  # Tratamiento de la excepción
#           puts e
#end
#      alu1=Alumno.new("Jorge", "Medicina")
#      puts alu1.inspect
#      alu2=Alumno.new("Carmen", "Empresariales", true)
#      puts alu2.inspect    
 

## --------1.2 Devolución(return) de varios objetos y uso de to_s (redefinido)----------
#
#alu = Alumno.new('juan','infor',true)
#a, b, c = alu.to_s
#puts "uso del put: ", a, b, c 
#print "uso del print: ", a, b, c

#
##-------------2. Sobrecarga de método -----------------------------------------
##  En Ruby los metodos no pueden sobrecargarse pero un solo método puede ser llamado
##  con diferentes argumentos (como el método initialize).
#   

#class Carrera   
#	def initialize(kilometros)
#		@kilometros=kilometros
#	end
#	def correr (distancia = 60, unLugar)		 
#  		 @kilometros+=distancia			 
#         @lugar=unLugar
#    end
#  end
 
#

## ----------- 2.1 Uso de métodos con distintos número de argumentos ----------- 
#
#car1=Carrera.new(40)
#car1.correr(5,'Granada')
#puts car1.inspect
#
##car1=Carrera.new(40)
#car1.correr(10) 
#puts car1.inspect  # plantéate qué pasa
#
#car1=Carrera.new(40)
#car1.correr     # error, modifica el método correr para que no se produzca el error
#puts car1.inspect 
#

## ------------------- 3. Distintos tipos de variables -----------------------------------------
##------------------3.1 Constante dentro de un módulo y de una clase ------------------------------
## Las constantes de definen en mayúscula

#module Figuras 
#PI= 3.141592
#  class Circulo
#    LADOS = 0
#    def ver_lados
#      puts LADOS
#    end
#    def area(radio)
#      PI*radio*radio
#    end
#  end
#  
#  puts "dentro del módulo"
#  puts PI
#  puts Circulo::LADOS
#  cir = Circulo.new
#  puts cir.area(3)
#end
#
#puts "fuera del módulo"
#puts Figuras::PI
#puts Figuras::Circulo::LADOS
#cir = Figuras::Circulo.new
#puts cir.area(3)
#Figuras::Circulo::LADOS = 2 # error constante ya inicializada
#
 
## --------------------- 3.2 Variables globales ------------------------------------
## Se definen anteponiéndole $ 
#
#$velocidad_maxima = 120
#
#class ControlTrafico  
#  def self.ponerMulta(velocidad)
#   if velocidad > $velocidad_maxima 
#     print "En la clase: debes pagar una multa de tráfico tienes un exceso de velocidad de " , velocidad-$velocidad_maxima, "km/h \n"
#   end
#  end  
#end
#
#def ponerMulta(velocidad)
#    if velocidad > $velocidad_maxima 
#     print "Fuera de clase y módulo: debes pagar una multa de tráfico tienes un exceso de velocidad de " , velocidad-$velocidad_maxima, "km/h \n"
#   end
#end
#
#module Trafico  
#  print "En el modulo: debes pagar una multa de tráfico tienes un exceso de velocidad de " , 200-$velocidad_maxima, "km/h \n" 
#end
#
#ponerMulta(200)
#ControlTrafico.ponerMulta(200)
#
#puts "Se cambia el creiterio de velocidad máxima===================="
#$velocidad_maxima = 140
#ponerMulta(200)
#ControlTrafico.ponerMulta(200)

## Ejercicio: Cambiar el lugar en el que se define la variable global (dentro de la clase y del módulo) probar qué ocurre
#

##--------------------3.3 Variables y Métodos de clase---------------------------
#
#class Coche
#  
# @@año  # variable de la clase
#
# def initialize(unModelo, unAño) 
#   @modelo=unModelo  # variable de instancia
#   @@año = unAño
# end
#
# def self.fecha(año) # Método de clase
#   @@año=año#	  
# end	 
# def to_s # Método de instancia y definido para todos los objetos
#	  "soy un coche  modelo #{@modelo} me fabricaron en  #{@@año}"
# end
#end
#
#coches = Array.new 
#coches << Coche.new("Clio", 2000)
#coches << Coche.new("Corsa", 2005)
#coches << Coche.new("Polo", 2010)
#coches.each { |coche| puts coche  } # ¿qué ocurre? y ¿por qué?
#
#puts "se cambia la fecha de fabricación ==========================="
#Coche.fecha(100)
#coches.each { |coche| puts coche  } # ¿qué ocurre? y ¿por qué?


##----------- 4. Delegación:  Una clase quiere usar algún método de otra. 
##
#
#require 'forwardable'
#class Grupo
#  extend Forwardable  # The Forwardable module provides delegation of specified methods to a designated object, 
#                                 #   using the methods def_delegator and def_delegators.
#	def initialize
#		@miembros=[]   
#	end 
#	def_delegators :@miembros, :size, :<<  # métodos de la clase Array que son usados por esta clase.
#  
#end
##
#g=Grupo.new #
#g<<1
#g<<9
#puts g.size
#puts g.inspect 
#

##---------------5. Incluir un módulo dentro de una clase ----------------------
## En la prueba del código hay un error corrígelo
#
#class Zapato
#  include Comparable  # Módulo que tiene la operación <=>, que es usada por sort
#  
#  attr_accessor  :color, :talla, :precio
#  def initialize(unaTalla, unColor)
#    @talla=unaTalla
#    @color=unColor
#    @precio=15 + unaTalla*0.2	
#  end 
#  private :talla
#  
#  def to_s
#    "soy de color #{@color} mi talla es la #{@talla} y valgo #{@precio} €"
#  end
#
#  def <=>(otro_zapato)
#    if self.talla < otro_zapato.talla
#     -1 # false
#    elsif self.talla > otro_zapato.talla
#     1  # true
#    else
#      0
#    end
#  end
#end
##
#
#zapato1= Zapato.new(40, 'azul')
#zapato2= Zapato.new(38,'verde')
#zapato3 = Zapato.new(45, 'negro')
#puts zapato1<=>zapato2
##
#tienda=[zapato1, zapato2, zapato3]
#tienda.sort! {|a,b| a<=> b}   # Los ordena según la talla, que es lo indicado en el <=> definido para Zapato
#tienda.each {|zapato| puts zapato.to_s}
# 
 
 
 