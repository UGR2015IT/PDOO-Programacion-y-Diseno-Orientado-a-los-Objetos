#encoding: utf-8

## -----------------------------------------------------------------------------
##  ------------------------------- Explicación ------------------------------
=begin 
    Cada bloque a probar está identificado por un número.
    Las líneas de código a probar tienen al comienzo un único caracter(#) de comentario.
    Las líneas de comentario tienen al comienzo dos caracteres de comentario
  Procede de la siguiente forma:
  - Quita los comentarios de las líneas de código del bloque correspondiente,
    para ello selecciona el trozo de código que se quiere probar y en el menú
    principal: fuente(Source)/Alternar Comentar(Toggle comment).
  - Prueba el trozo de código con MAY-F6. Modifica el código todo lo que quieras.
  - Una vez probado y entendido coloca de nuevo los comentarios, para ello seleccionar
    el trozo de código que se quiere comentar y en el menu principal de nuevo:
     fuente(Source)/Alternar Comentar(Toggle comment)
  - Procede de la misma forma con todos los bloques de código.
 
------------------------------------------------------------------------------
   Comienza con los siguientes archivos, en este orden y con la sistemática 
   indicada anteriormente:   

   - Ejemplos_UsoClases 
   - Ejemplos_Hash_avanzados
   - Ejemplos_copia_avanzados

=end

## 
##
