# To change this template, choose Tools | Templates
# and open the template in the editor.
 
module X
  class E 
    
  end       
end
