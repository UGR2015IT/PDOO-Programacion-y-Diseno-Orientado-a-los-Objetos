# To change this template, choose Tools | Templates
# and open the template in the editor.
 
module X
  module Y
    class C
     
    end
    
  end
end
