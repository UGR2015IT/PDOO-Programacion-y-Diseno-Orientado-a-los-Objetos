/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package X.Z;
 
 
/**
 *
 * @author ana
 */
public class D {
    private  X.Y.C c;
    private X.E e;
    private X.Z.V.B b;
    private X.Y.U.A a;
}
