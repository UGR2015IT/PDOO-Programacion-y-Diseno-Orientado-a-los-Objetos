/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package X.Z.V;


/**
 *
 * @author ana
 */
public class B {
    private F f;
    private X.E e;
    private X.Y.C c;
    private X.Z.D d;
    private X.Y.U.A a;
}
