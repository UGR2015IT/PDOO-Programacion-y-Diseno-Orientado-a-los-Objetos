/* Ejemplo de relaciones entre objetos */

package el_ciclista;
 
public class PruebaCiclista {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bicicleta miBici = new Bicicleta();
        Club miClub = new Club("los intrépidos", "trevenque 2, bajo B");
        Ciclista ciclista = new Ciclista("Pepe",30,miBici,miClub);
        System.out.println(ciclista.toString());
        Bicicleta tuBici = new Bicicleta(6, "verde");
        tuBici.desplazarse("Murcia");
        // Continúa haciendo pruebas de todo el código
    }
    
}
