#encoding: UTF-8

# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module El_Ciclista
  class Bicicleta
  
     attr_accessor  :color; # variable de instancia de la que se genera de forma automática el consultor y modificador de color
     attr_reader    :marcha, :NUMEROSERIE, :kilometrosRecorridos; # variables de instancia de las que se genera de forma automática el consultor de estos atributos
  
    @@NumeroBicicletas=0  # Variable de ámbito de clase, compartida por la clase, el módulo y submodulos en el que está definida
    @@NUMERORUEDAS=2      # Igual que la anterior
 
    def initialize(unaMarcha=0, unColor="gris") # inicializador de los atributos 
      
      @marcha=unaMarcha 
      @color =unColor
      
      @kilometrosRecorridos= 0
      Bicicleta.incrementarNumeroBicicletas;
      @NUMEROSERIE=@@NumeroBicicletas+1  
    end
    
    
    
  # consultores
  def self.numeroBicicletas  # Método de instancia de clase
    @@NumeroBicicletas
  end 
  
  
  def self.incrementarNumeroBicicletas # Método de clase
    @@NumeroBicicletas += 1
  end 
 
  def numeroRuedas # Método de instancia que accede a variable de ámbito de clase
    @@NUMERORUEDAS;
    
  end     
 
  def hacerRuta(lugar, km)
     desplazarse(lugar)      
     incrementarKilometros(km)   # llamando a un método private no puede usarse self
     
  end  

  def desplazarse(lugar)
   puts "Voy a ir a #{lugar}"
  end  
  
  def to_s
    "Soy una bicicleta de #{@marcha} marchas y soy de color #{@color}"
  end
  
  private  # los siguientes metodos son privados     
   
  def incrementarKilometros(km)
       @kilometrosRecorridos += km
      
  end 
   
  end # fin de la clase
  

end # fin del modulo UnModulo