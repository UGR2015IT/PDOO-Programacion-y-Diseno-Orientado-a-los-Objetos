#encoding: utf-8 

#Ejemplo en Ruby que ilustra la creación de varios constructores en una clase 
# utilizando métodos de clase 
# SEGUNDA FORMA más fácil

class Test

  attr_reader :a,:b,:c,:d

  def initialize(a,b,c,d)
    @a=a
    @b=b
    @c=c
    @d=d
  end  
  
  def to_s
    "Objeto de test #{@a},#{@b},#{@c},#{@d}"
  end  
  
  #Métodos de instancia de clase que son los nuevos constructores

  def Test.newAB(a,b)  
       new(a,b,nil,nil) # entrar con nil no es una buena opción, habría que entrar con valores.  
  end
  
  def self.newCD(c,d)
       new(nil,nil,c,d)
  end 
  
  #Pone como privado el método constructor new para que no podamos usarlo desde fuera de la clase  
  private_class_method :new
  
end

#Probando

    test= Test.newAB(1,2)
    puts test
    puts test.object_id
    

    test= Test.newCD(3,4)
    puts test   
    puts test.object_id

#    test= Test.new(1,2,3,4)

#    test= Test.new   

# Descomentar una a una las líneas de código últimas y explicar el motivo del error