
package test;

import modelo.FiguraGrafica;
import modelo.Rectangulo;


public class RelacionesEntreInterfaces {


    public static void main(String[] args) {
        Rectangulo r = new Rectangulo(2,3);
        r.colorear("azul");
        r.pintarBorde("amarillo");
        
        
        //Presta atención a que la variable grosorBorde parece tener visibilidad de paquete en FiguraGrafica
        System.out.println("El grosor del borde es "+FiguraGrafica.grosorBorde);
        //¿Qué pasaría con la instrucción anterior si FiguraGrafica tuviese visibilidad de paquete?
        
        
        FiguraGrafica r2 = new Rectangulo(3,4); //¡Funciona! lo veremos en polimorfismo
    }
    
}
