
package modelo;


public interface FiguraGrafica {
  int grosorBorde=2;
  public void pintarBorde(String color);
  public void colorear(String color);
}
