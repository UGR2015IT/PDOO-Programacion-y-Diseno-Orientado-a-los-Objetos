/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;



public class Rectangulo implements FiguraGrafica{

    private float ladoA;
    private float ladoB;
    
    public Rectangulo(float a, float b){
        ladoA=a;
        ladoB=b;
    }
    
    //¿Por qué tiene override este método?
    @Override
    public void colorear(String color)
    {
        System.out.println("Relleno de "+color);
    }

    @Override
    public void pintarBorde(String color) {
        System.out.println("Pinto un borde "+color+" de grosor "+grosorBorde);
    }
    
    //¿Por qué este método no tiene override?
    public void pintarBorde(){
        pintarBorde("negro");
    }
    
   
    
}
