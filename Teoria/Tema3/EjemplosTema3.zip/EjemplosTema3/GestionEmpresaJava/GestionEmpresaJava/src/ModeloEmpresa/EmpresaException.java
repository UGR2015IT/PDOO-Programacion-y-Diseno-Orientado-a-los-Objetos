package ModeloEmpresa;

public class EmpresaException extends Exception {

    EmpresaException(String error){
        super(error);
    }

}
