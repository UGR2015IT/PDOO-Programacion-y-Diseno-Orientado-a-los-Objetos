/*
 * Material complementario del tema 3 de PDOO
 * Pruebas para ver cómo afecta la visibilidad establecida para atributos y métodos
 * cuando existen relaciones de herencia
 */
package pruebavisibilidadherencia;

public class Mamifera {
    
    private static int contadorMamiferos=0;
    private int edad;
    private float peso;
    protected int numCrias;
    
    Mamifera(float peso){
        contadorMamiferos++;
        edad=0;
        setPeso(peso);
    }
    
    public static int cuantosMamiferos(){
        return contadorMamiferos;
    }
    
    public int getEdad(){
        return edad;
    }
    
    public float getPeso(){
        return peso;
    }
    
    public void setPeso(float peso){
        this.peso = peso;
    }
    
    public void gestarCria(){
        System.out.println("Gesto a la cría en el útero");
    }
    
    public void alimentarCria(){
        System.out.println("Doy de mamar a la cría");
    }
    
    public static void main(String[] args) {
        Mamifera yegua = new Mamifera(15);
        System.out.println("Mi edad es "+yegua.edad+" y mi peso "+yegua.peso);
        yegua.gestarCria();
        yegua.alimentarCria();
        System.out.println("Hay "+contadorMamiferos+" mamíferos en este sistema");
        System.out.println("Hay "+cuantosMamiferos()+" mamíferos en este sistema");
        System.out.println("Hay "+this.cuantosMamiferos()+" mamíferos en este sistema");
        System.out.println("Hay "+yegua.cuantosMamiferos()+" mamíferos en este sistema");
    }
}
