/*
 * Material complementario del tema 3 de PDOO
 * Pruebas para ver cómo afecta la visibilidad establecida para atributos y 
 * métodos cuando existen relaciones de herencia
 */
package pruebavisibilidadherencia;

public class Ornitorrinca extends Mamifera{
    
    private float tamanyoPico;
    
    Ornitorrinca(float peso, float tam){
        super(peso);
        tamanyoPico = tam;
    }
    
    @Override
    public void gestarCria(){
        System.out.println("Pongo huevos");
    }
    
    public static void main(String[] args) {
        
        Mamifera yegua = new Mamifera(15);
        //System.out.println("Mi edad es "+yegua.edad+" y mi peso "+yegua.peso);
        //yegua.peso = 20;
        yegua.setPeso(20);
        yegua.numCrias = 20;
        System.out.println("Mi edad es "+yegua.getEdad()+" y mi peso "+yegua.getPeso());
        yegua.gestarCria();
        yegua.alimentarCria();
        
        Ornitorrinca orni = new Ornitorrinca(1,5);
        System.out.println("Mi edad es "+orni.edad+", mi peso es "+orni.peso+" y el tamaño de mi pico es "+orni.tamanyoPico);
        orni.gestarCria();
        orni.alimentarCria();
        
       // System.out.println("Hay "+contadorMamiferos+" mamíferos en este sistema");
        System.out.println("Hay "+cuantosMamiferos()+" mamíferos en este sistema");
    }
}
