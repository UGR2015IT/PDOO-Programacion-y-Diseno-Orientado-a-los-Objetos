# To change this template, choose Tools | Templates
# and open the template in the editor.
require_relative 'empleado_asalariado'

module ModeloEmpresa

class Director < EmpleadoAsalariado
  def initialize(nom,dni,sal)
    super(nom,dni,sal)
    @subordinados = Array.new     
  end
  def subordinados
    salida = "los empleados de ese director son : \n"
    @subordinados.each {|emp| salida += emp.to_s + "\n"}
    return salida
  end 
  def incluirSubordinado(empleado)
    raise EmpresaException.new('Ese emplado ya tiene director') if empleado.tieneDirector
    raise EmpresaException.new('Ese emplado es director y no puede ser subordinado') if empleado.esDirector
    @subordinados << empleado
    empleado.establecerDirector(self)
  end
  def esDirector
    true
  end
  def eliminarSubordinado(empleado)
    raise EmpresaException.new('Ese emplado no esta subordinado a este director') unless  @subordinados.delete(empleado) !=nil
    empleado.sinDirector
  end
  def sinSubordinados
    @subordinados.each { |empleado| empleado.sinDirector  }
    @subordinados.clear
  end
  def to_s
    super +  'y soy director'
  end
end
end
