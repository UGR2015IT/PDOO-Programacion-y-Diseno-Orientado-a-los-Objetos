# To change this template, choose Tools | Templates
# and open the template in the editor.
require_relative 'empleado'
require_relative 'empresa_exception'

module ModeloEmpresa

class EmpleadoAsalariado  
   
  attr_accessor :salario
  def initialize(nom,dni,sal)
    super(nom,dni)
    @salario=modificarPagos(sal)
  end    
  public_class_method :new
  def nomina
    @salario -(@salario*@@retencion)/100
  end
  def sueldo
    @salario 
  end  
  def modificarPagos(nuevoPago)
    raise EmpresaException.new('sueldo inferior a 600 euros') if(nuevoPago<600)
    @salario = nuevoPago        
  end  
  def to_s
    super.to_s + ' gano : ' + salario.to_s  
  end
end
end