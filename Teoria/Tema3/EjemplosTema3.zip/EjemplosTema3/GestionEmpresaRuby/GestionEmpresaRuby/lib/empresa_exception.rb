# To change this template, choose Tools | Templates
# and open the template in the editor.
module ModeloEmpresa
class EmpresaException < StandardError
  def initialize(error)
    super(error)    
  end
end
end
