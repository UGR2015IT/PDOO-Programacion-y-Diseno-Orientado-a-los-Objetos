# To change this template, choose Tools | Templates
# and open the template in the editor.
require_relative 'empleado'

module ModeloEmpresa
class EmpleadoPorHoras  
   
  attr_reader :precioHora 
  attr_accessor :horasTrabajadas
  def initialize(nom,dni,prHora)
    super(nom,dni)
    @precioHora = modificarPagos(prHora)
    @horasTrabajadas = 0    
  end
  public_class_method :new
  def modificarPagos(ph)
    raise EmpresaException.new('el precio de la hora no puede ser inferior a 6 euros') if ph <6
    @precioHora = ph    
  end
  def incrementarHoras(horas)
    @horasTrabajadas += horas
  end
  def inicializarHoras
    @horasTrabajadas = 0
  end
  def sueldo
    horasTrabajadas * precioHora
  end
  def nomina
    nomin = (@precioHora*@horasTrabajadas)- (@precioHora*@horasTrabajadas)*@@retencion/100
    inicializarHoras
    nomin
  end
  def to_s
    super.to_s + ' precio de la hora trabajada = ' + @precioHora.to_s
  end
end
end