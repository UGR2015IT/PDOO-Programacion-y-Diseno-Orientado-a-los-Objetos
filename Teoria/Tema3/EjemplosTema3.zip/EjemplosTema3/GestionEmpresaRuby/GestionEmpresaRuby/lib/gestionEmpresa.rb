# Encoding: utf-8

=begin
# El código está para que funcione con la clase Empleado como 
# clase abstracta poniendo el new como método privado
# Ejercicio: hacer las modificaciones necesarias para que funcione con el módulo 
# Empleado como clase abstracta (module_empleado).
=end

require_relative 'director'
require_relative 'empleado_por_horas'
require_relative 'empresa_exception'
require_relative 'empleado'
module ModeloEmpresa 
 def self.menuInicio
    # Menu principal, donde se contemplan las operaciones generales que se pueden llevar a cabo.
 
   print "===========================================\n"+
           "1. Contratar empleados"+"\n"+
           "2. Director y sus empleados"+"\n"+
           "3. Modificar Sueldo/Precio de hora"+"\n"+
           "4. Incrementar horas trabajadas"+"\n"+
           "5. Calcular nomina de todos los empleados"+"\n"+
           "6. Despedir empleado"+"\n"+
           "7. Mostrar todos los empleados" +"\n" +     
           "0. Terminar\n"+
          "====================================================\n"
        gets.chomp
 end 
 def self.menuDirector
    print  "===========================================\n" +
            "1. Subordinar un empleado a un director" + "\n" +
            "2. Desubordinar un empleado a un director" + "\n" +
            "3. Modificar el director de un empleado" + "\n" +
            "4. Promocionar empleado a director" + "\n" +
            "5. Destituir a un Director" + "\n" +
            "6. Ver empleados de un director" + "\n" +
            "OTRO VALOR = Menu principal" + "\n" +
        "====================================================\n" 
       gets.chomp
 end
 def self.menuEmpleado
    print  "==========================================\n"+
            "1. Asalariado"+"\n"+ 
            "2. Por horas"+"\n"+
            "3. Director"+"\n"+
    "=============================================="+"\n" 
    gets.chomp
 end
 def self.buscarEmpleado(dniE,empleados)    
   if empleados.include?(dniE)
     empleados[dniE]
   else
     raise EmpresaException.new('Empleado no encontrado')
   end       
 end
 

 opcion1 = 10
 empleados=Hash.new  
 until opcion1 == 0
  begin
    opcion1=menuInicio.to_i  
    case opcion1
      when 1  
        puts '=== CONTRATAR EMPLEADO ==='
        puts 'Introduzca el nombre'
        nombre = gets.chomp
        puts 'Introduzca el dni'
        dni = gets.chomp 
        puts'Introduzca el sueldo o precio de la hora'
        sueldo = gets.chomp.to_f 
        opcion2 = menuEmpleado.to_i
        case opcion2
          when 1 # Contratar a un empleado asalariado
            empleados[dni] = EmpleadoAsalariado.new(nombre,dni,sueldo)
          when 2 # Contratar a un emplado por horas
            empleados[dni] = EmpleadoPorHoras.new(nombre,dni,sueldo)
          when 3 # Contratar a un director
            empleados[dni] = Director.new(nombre,dni,sueldo)
        end
        empleados.values.each { |emp|   puts emp.to_s}     
       
      when 2 # todas las operaciones del director
        opcion3 = menuDirector.to_i
        case opcion3
          when 1 
            puts '=== SUBORDINAR UN EMPLEADO A UN DIRECTOR ==='
            puts 'DNI del director'
            dniD = gets.chomp
            director = buscarEmpleado(dniD,empleados)
            puts 'DNI del empleado'
            dniE = gets.chomp 
            empleado = buscarEmpleado(dniE,empleados)
            director.incluirSubordinado(empleado)
          when 2
            puts '=== DESUBORDINAR UN EMPLEADO DE UN DIRECTOR ==='
            puts 'DNI del empleado'
            dniE = gets.chomp 
            empleado = buscarEmpleado(dniE,empleados)
            empleado.eliminarSubordinacion
          when 3
            puts '=== CAMBIAR EMPLEADO DE DIRECTOR ==='           
            puts 'DNI del nuevo director'
            dniD = gets.chomp
            director = buscarEmpleado(dniD,empleados)
            puts 'DNI del empleado'
            dniE = gets.chomp 
            empleado = buscarEmpleado(dniE,empleados)
            empleado.eliminarSubordinacion if empleado.tieneDirector
            director.incluirSubordinado(empleado)
          when 4
            puts '=== PROMOCIONAR EMPLEADO A DIRECTOR ==='
            puts 'DNI del empleado'
            dniE = gets.chomp 
            empleado = buscarEmpleado(dniE,empleados)
            empleado.eliminarSubordinacion if empleado.tieneDirector           
            empleados[dniE] = Director.new(empleado.nombre,empleado.dni,empleado.sueldo)
          when 5
            puts '=== DESTITUIR A UN DIRECTOR ==='
            puts 'DNI del director'
            dniD = gets.chomp
            director = buscarEmpleado(dniD,empleados)
            director.sinSubordinados
            empleados[dniD]= EmpleadoAsalariado.new(director.nombre,director.dni,director.sueldo)
          when 6
            puts '=== VER LOS EMPLEADOS DE UN DIRECTOR ==='
            puts 'DNI del director'
            dniD = gets.chomp
            director = buscarEmpleado(dniD,empleados)
            puts director.subordinados
          else 
            puts 'opción no válida'
       end
     when 3
        puts '=== MODIFICAR SUELDO/PRECIO HORA ==='
        puts 'DNI del empleado'
        dniE = gets.chomp 
        empleado = buscarEmpleado(dniE,empleados)
        puts 'Nuevo sueldo o precio hora'
        sueldo = gets.chomp.to_f 
        empleado.modificarPagos(sueldo)
     when 4
        puts '=== INCREMENTAR HORAS TRABAJADAS ==='
        puts 'DNI del empleado por horas'
        dniE = gets.chomp 
        empleado =buscarEmpleado(dniE,empleados)
        puts 'Horas trabajadas'
        horas = gets.chomp.to_f 
        empleado.incrementarHoras(horas)
     when 5
       puts '=== NOMINA DE TODOS LOS EMPLEADOS ==='
       empleados.values.each do  |emp| 
         puts emp.to_s
         puts "nomina:  #{emp.nomina}"
       end
     when 6
       puts '=== DESPEDIR EMPLEADO ==='
        puts 'DNI del empleado'
        dniE = gets.chomp 
        empleado =buscarEmpleado(dniE,empleados)
        empleado.sinSubordinados if empleado.esDirector
        empleado.eliminarSubordinacion if empleado.tieneDirector
        empleados.delete(dniE)  
     when 7
       puts 'todos los empleados de la empresa'
       empleados.values.each { |emp| puts emp.to_s  }
     when 0
     else
        print 'opcion no válida'
   end   
   rescue EmpresaException => e
     puts e.message
  end
end
end
