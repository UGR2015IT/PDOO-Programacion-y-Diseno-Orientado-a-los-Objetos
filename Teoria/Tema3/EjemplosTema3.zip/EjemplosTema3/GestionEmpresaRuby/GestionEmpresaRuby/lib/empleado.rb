# To change this template, choose Tools | Templates
# and open the template in the editor.

module ModeloEmpresa  
 
class Empleado
  attr_accessor :nombre, :dni
  @@retencion = 20
  def initialize(nom,dni)    
    @nombre = nom
    @dni = dni
    @director = nil
  end
  private_class_method :new # Para hacer que la clase sea abstracta y no se pueda usar el new
   
  def establecerDirector(dir)
    @director = dir
  end
  def nomina
     raise NotImplementedError.new # Método sin implementación en Empleado
  end   
  def sinDirector
    @director = nil     
  end
  def eliminarSubordinacion
    @director.eliminarSubordinado(self)
    sinDirector
  end
  def tieneDirector
    @director != nil
  end
  def to_s
    salida = 'dni : ' + dni + ', nombre : ' + nombre 
  # + 'mi director es:' + miDirector
  end
  def modificarPagos(nPagos)
    reaise NotImplementedError.new
  end
  def miDirector
    raise EmpresaException.new('no tiene director') if @director == nil
    "mi director es : " +  @director.nombre
  end
  def esDirector
    false
  end
  
end
end